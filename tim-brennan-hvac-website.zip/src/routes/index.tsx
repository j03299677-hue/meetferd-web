import { createFileRoute } from "@tanstack/react-router";
import { Phone, MapPin, Clock, Star, Snowflake, Flame, Wrench, ArrowRight } from "lucide-react";
import hero from "@/assets/hero.jpg";
import ac from "@/assets/ac.jpg";
import heating from "@/assets/heating.jpg";
import repair from "@/assets/repair.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Tim Brennan Heating & Air Conditioning | Carlsbad HVAC, 24/7" },
      { name: "description", content: "Honest, affordable heating and AC installation and repair in Carlsbad, CA. Open 24 hours. Call 760-583-8083." },
      { property: "og:title", content: "Tim Brennan Heating & Air Conditioning" },
      { property: "og:description", content: "24/7 heating and air conditioning service in Carlsbad, CA." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const PHONE = "+1 760-583-8083";
const TEL = "tel:+17605838083";

const services = [
  { img: ac, icon: Snowflake, title: "AC Installation", text: "Full system replacements sized right for your home — at prices that beat the big companies." },
  { img: heating, icon: Flame, title: "Heating Systems", text: "Furnace and heat pump installs, tune-ups and repairs to keep winters comfortable." },
  { img: repair, icon: Wrench, title: "Repairs & Maintenance", text: "Fast diagnosis, smart thermostats and preventive care, day or night." },
];

const reviews = [
  { name: "Natalie B.", text: "My two 20 year old heater/cooler systems needed replacement for my entire 4,000 sq ft house. Tim was $4,000–$6,000 cheaper than the nearest other quotes for the same size York units." },
  { name: "Dylan", text: "Excellent work! Replaced my 4 ton heat and cool system that went out during a heatwave. Came out fast and had it done fast! Thank you Tim!" },
];

function Index() {
  return (
    <div className="font-sans">
      {/* Header */}
      <header className="absolute inset-x-0 top-0 z-20">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-5">
          <a href="#" className="font-display text-lg font-extrabold text-primary-foreground">
            TIM BRENNAN <span className="text-accent">HVAC</span>
          </a>
          <nav className="hidden gap-8 text-sm text-primary-foreground/80 md:flex">
            <a href="#services" className="hover:text-primary-foreground">Services</a>
            <a href="#about" className="hover:text-primary-foreground">About</a>
            <a href="#reviews" className="hover:text-primary-foreground">Reviews</a>
            <a href="#contact" className="hover:text-primary-foreground">Contact</a>
          </nav>
          <a href={TEL} className="flex items-center gap-2 rounded-md bg-accent px-4 py-2 text-sm font-semibold text-accent-foreground transition hover:brightness-110">
            <Phone className="h-4 w-4" /> <span className="hidden sm:inline">{PHONE}</span><span className="sm:hidden">Call</span>
          </a>
        </div>
      </header>

      {/* Hero with moving background */}
      <section className="relative flex min-h-[92vh] items-center overflow-hidden bg-brand-deep">
        <img src={hero} alt="Technician installing an air conditioner at a Carlsbad home" width={1920} height={1088} className="hero-media absolute inset-0 h-full w-full object-cover" />
        <div className="hero-overlay absolute inset-0" />
        <div className="relative z-10 mx-auto w-full max-w-7xl px-6 py-32">
          <div className="max-w-2xl">
            <p className="mb-5 inline-flex items-center gap-2 rounded-full border border-primary-foreground/20 px-3 py-1 text-xs uppercase tracking-widest text-primary-foreground/80">
              <Clock className="h-3.5 w-3.5 text-accent" /> Open 24 hours · Carlsbad, CA
            </p>
            <h1 className="font-display text-5xl font-extrabold leading-[1.05] text-primary-foreground md:text-7xl">
              Comfort restored. <span className="text-accent">Fair prices.</span>
            </h1>
            <p className="mt-6 max-w-xl text-lg text-primary-foreground/80">
              Heating and air conditioning installs and repairs from a local contractor who shows up fast and quotes honestly.
            </p>
            <a href="#contact" className="mt-8 inline-flex items-center gap-2 rounded-md bg-primary px-7 py-4 font-semibold text-primary-foreground transition hover:-translate-y-0.5 hover:brightness-110">
              Get a Free Quote <ArrowRight className="h-4 w-4" />
            </a>
            <form onSubmit={(e) => e.preventDefault()} className="email-field mt-6 flex max-w-md overflow-hidden rounded-md border border-border bg-card">
              <label htmlFor="hero-email" className="sr-only">Email</label>
              <input id="hero-email" type="email" placeholder="Enter your email for a free estimate" className="w-full bg-transparent px-4 py-3.5 text-foreground outline-none placeholder:text-muted-foreground" />
              <button type="submit" className="bg-brand-deep px-5 text-sm font-semibold text-primary-foreground">Send</button>
            </form>
          </div>
        </div>
      </section>

      {/* Services */}
      <section id="services" className="mx-auto max-w-7xl px-6 py-24">
        <p className="text-sm font-semibold uppercase tracking-widest text-primary">Services</p>
        <h2 className="mt-2 font-display text-4xl font-extrabold text-foreground">Everything your system needs</h2>
        <div className="mt-12 grid gap-8 md:grid-cols-3">
          {services.map((s) => (
            <article key={s.title} className="img-hover rounded-lg border border-border bg-card">
              <div className="aspect-[4/3] overflow-hidden">
                <img src={s.img} alt={s.title} loading="lazy" width={1024} height={768} className="h-full w-full object-cover" />
              </div>
              <div className="p-6">
                <s.icon className="h-6 w-6 text-primary" />
                <h3 className="mt-3 font-display text-xl font-semibold text-card-foreground">{s.title}</h3>
                <p className="mt-2 text-muted-foreground">{s.text}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* About */}
      <section id="about" className="bg-secondary">
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-6 py-24 md:grid-cols-2">
          <div className="img-hover rounded-lg">
            <img src={heating} alt="Tim Brennan technician inspecting a furnace" loading="lazy" width={1024} height={768} className="w-full object-cover" />
          </div>
          <div>
            <p className="text-sm font-semibold uppercase tracking-widest text-primary">About</p>
            <h2 className="mt-2 font-display text-4xl font-extrabold text-foreground">A local contractor, not a call center</h2>
            <p className="mt-5 text-lg text-muted-foreground">
              Tim Brennan Heating & Air Conditioning serves homes and businesses across Carlsbad and North County San Diego. You deal directly with Tim — clear quotes, quality equipment, and work done right the first time.
            </p>
            <div className="mt-8 grid grid-cols-3 gap-4 text-center">
              {[["24/7", "Availability"], ["$4K+", "Typical savings"], ["Local", "Carlsbad based"]].map(([a, b]) => (
                <div key={b} className="rounded-lg bg-card p-4">
                  <div className="font-display text-2xl font-extrabold text-primary">{a}</div>
                  <div className="text-xs text-muted-foreground">{b}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Reviews */}
      <section id="reviews" className="mx-auto max-w-7xl px-6 py-24">
        <p className="text-sm font-semibold uppercase tracking-widest text-primary">Testimonials</p>
        <h2 className="mt-2 font-display text-4xl font-extrabold text-foreground">What customers say</h2>
        <div className="mt-12 grid gap-8 md:grid-cols-2">
          {reviews.map((r) => (
            <figure key={r.name} className="rounded-lg border border-border bg-card p-8 transition hover:-translate-y-1 hover:shadow-lg">
              <div className="flex gap-1 text-accent">{Array.from({ length: 5 }).map((_, i) => <Star key={i} className="h-4 w-4 fill-current" />)}</div>
              <blockquote className="mt-4 text-lg text-card-foreground">“{r.text}”</blockquote>
              <figcaption className="mt-4 font-semibold text-muted-foreground">— {r.name}</figcaption>
            </figure>
          ))}
        </div>
      </section>

      {/* Contact */}
      <section id="contact" className="bg-brand-deep text-primary-foreground">
        <div className="mx-auto grid max-w-7xl gap-12 px-6 py-20 md:grid-cols-2">
          <div>
            <h2 className="font-display text-4xl font-extrabold">Need heat or AC now?</h2>
            <p className="mt-4 text-primary-foreground/70">Call any time, day or night, or leave your email for a free estimate.</p>
            <form onSubmit={(e) => e.preventDefault()} className="email-field mt-8 flex max-w-md overflow-hidden rounded-md border border-border bg-card">
              <label htmlFor="footer-email" className="sr-only">Email</label>
              <input id="footer-email" type="email" placeholder="Enter your email for a free estimate" className="w-full bg-transparent px-4 py-3.5 text-foreground outline-none placeholder:text-muted-foreground" />
              <button type="submit" className="bg-primary px-5 text-sm font-semibold text-primary-foreground">Send</button>
            </form>
          </div>
          <ul className="space-y-5 text-lg">
            <li className="flex gap-3"><Phone className="h-6 w-6 text-accent" /><a href={TEL} className="hover:text-accent">{PHONE}</a></li>
            <li className="flex gap-3"><MapPin className="h-6 w-6 text-accent" />3024 Newshire St, Carlsbad, CA 92010</li>
            <li className="flex gap-3"><Clock className="h-6 w-6 text-accent" />Open 24 hours, 7 days</li>
          </ul>
        </div>
        <p className="border-t border-primary-foreground/10 py-6 text-center text-sm text-primary-foreground/50">
          © {new Date().getFullYear()} Tim Brennan Heating & Air Conditioning
        </p>
      </section>
    </div>
  );
}
